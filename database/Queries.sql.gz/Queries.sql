ALTER TABLE `visitor` ADD `visit_business_id` INT NOT NULL AFTER `visit_page`;
ALTER TABLE `business_listing` ADD `facebook_page` VARCHAR(250) NOT NULL AFTER `additional_info`, ADD `instagram_page` VARCHAR(250) NOT NULL AFTER `facebook_page`;
ALTER TABLE `business_listing` CHANGE `facebook_page` `facebook_page` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL;
ALTER TABLE `business_listing` CHANGE `instagram_page` `instagram_page` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL;



ALTER TABLE `business_listing` ADD `map_address` TEXT NULL DEFAULT NULL AFTER `location`;
ALTER TABLE `business_listing` ADD `website` VARCHAR(250) NULL DEFAULT NULL AFTER `additional_info`;



CREATE TABLE `business_reviews` (`id` INT NOT NULL AUTO_INCREMENT , `business_id` INT NOT NULL , `user_id` INT NOT NULL DEFAULT '0' , `user_name` TEXT NOT NULL , `email` VARCHAR(255) NULL , `phone_number` VARCHAR(15) NULL , `rating` INT NOT NULL , `comment` TEXT NULL , `created` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP , `status` INT NOT NULL DEFAULT '1' , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `business_reviews` CHANGE `business_id` `business_listing_id` INT(11) NOT NULL;

ALTER TABLE `business_listing` ADD `total_reviews` INT NOT NULL DEFAULT '0' AFTER `instagram_page`, ADD `avg_rating` FLOAT NOT NULL DEFAULT '0' AFTER `total_reviews`;


#Need to publish app google login
https://console.cloud.google.com/apis/credentials/consent?project=dgmenu

